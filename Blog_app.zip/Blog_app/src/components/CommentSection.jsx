import { useState } from "react";

function CommentSection() {
  const [comments, setComments] = useState([
    "Great post!",
    "Nice blog!",
  ]);
  const [input, setInput] = useState("");

  const addComment = () => {
    if (input !== "") {
      setComments([...comments, input]);
      setInput("");
    }
  };

  return (
    <div>
      <h3>Comments</h3>

      <textarea
        value={input}
        onChange={(e) => setInput(e.target.value)}
        placeholder="Add a comment"
      />

      <button onClick={addComment}>Submit</button>

      <ul>
        {comments.map((c, i) => (
          <li key={i}>{c}</li>
        ))}
      </ul>
    </div>
  );
}

export default CommentSection;