function Header() {
  return (
    <header className="header">
      <h1>My Blog</h1>
      <p>Thoughts and ideas</p>
    </header>
  );
}

export default Header;