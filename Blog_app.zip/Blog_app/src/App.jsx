import "./App.css";

import Header from "./components/Header";
import Navbar from "./components/Navbar";
import BlogPost from "./components/BlogPost";
import CommentSection from "./components/CommentSection";
import Footer from "./components/Footer";

import posts from "./data/posts";

function App() {
  return (
    <>
      <Header />
      <Navbar />

      {posts.map((post) => (
        <div key={post.id}>
          <BlogPost post={post} />
          <CommentSection />
        </div>
      ))}

      <Footer />
    </>
  );
}

export default App;